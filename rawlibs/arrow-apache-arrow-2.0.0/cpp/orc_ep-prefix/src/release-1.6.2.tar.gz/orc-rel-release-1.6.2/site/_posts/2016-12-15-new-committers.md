---
layout: news_item
title: "ORC adds new committers"
date: "2016-12-15 17:23:00 -0800"
author: omalley
categories: [team]
---

As part of the removal of the ORC code base from Hive, the ORC PMC has
offered to make any existing Hive committers into ORC committers. The new ORC
committers coming from Hive are:

* Aihua Xu
* Ashutosh Chauhan
* Carl Steinbach
* Chaoyu Tang
* Chinna Rao Lalam
* Daniel Dai
* Eugene Koifman
* Ferdinand Xu
* Jason Dere
* Jesus Camacho Rodriguez
* Jimmy Xiang
* Lars Francke
* Matthew McCline
* Mithun Radhakrishnan
* Naveen Gangam
* Pengcheng Xiong
* Rajesh Balamohan
* Rui Li
* Sergio Pena
* Siddharth Seth
* Vaibhav Gumashta
* Wei Zheng
* Yongzhi Chen
