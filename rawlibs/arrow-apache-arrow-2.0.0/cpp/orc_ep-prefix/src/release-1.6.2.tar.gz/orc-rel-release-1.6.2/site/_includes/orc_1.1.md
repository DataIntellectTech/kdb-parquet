The major new features in ORC 1.1 are:

- [ORC-1]({{site.jira}}/ORC-1) Copy the Java ORC code from Hive.
- [ORC-10]({{site.jira}}/ORC-10) Fix the C++ reader to correctly read
  timestamps from timezones with different daylight savings rules.
- [ORC-52]({{site.jira}}/ORC-52) Add mapred and mapreduce connectors.
