---
layout: news_item
title: "ORC adds Aliaksei Sandryhaila to PMC"
date: "2015-11-19 12:47:00 -0800"
author: omalley
categories: [team]
---

 On behalf of the Apache ORC Project Management Committee (PMC), it gives
me great pleasure to announce that Aliaksei Sandryhaila has joined the Apache
ORC PMC. He has done lot of good work on ORC and I'm looking forward to
more.

Please join me in welcoming Aliaksei to ORC PMC!

Congratulations Aliaksei!
