The new features of ORC 1.4:

- [ORC-72]({{site.jira}}/ORC-72) Add benchmark code for file formats.
- [ORC-87]({{site.jira}}/ORC-87) Fix timestamp statistics in C++.
- [ORC-150]({{site.jira}}/ORC-150) Add tool to convert from JSON.
- [ORC-151]({{site.jira}}/ORC-151) Reduce the size of tools.jar.
- [ORC-174]({{site.jira}}/ORC-174) Create a nohive variant of the jars.


