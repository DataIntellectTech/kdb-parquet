---
layout: news_item
title: "ORC adds Gopal Vijayaraghavan to PMC"
date: "2017-01-04 10:40:00 -0800"
author: omalley
categories: [team]
---

 On behalf of the Apache ORC Project Management Committee (PMC), it gives
me great pleasure to announce that Gopal Vijayaraghavan has joined the PMC.
Gopal has done an amazing job at speeding up ORC in many ways.

Please join me in welcoming Gopal to the ORC PMC!

Congratulations Gopal!
