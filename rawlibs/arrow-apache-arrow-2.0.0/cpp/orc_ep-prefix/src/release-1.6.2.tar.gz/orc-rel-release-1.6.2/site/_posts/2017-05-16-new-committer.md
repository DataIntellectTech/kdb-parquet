---
layout: news_item
title: "Deepak Majeti added as committer"
date: "2017-05-16 12:00:00 -0700"
author: omalley
categories: [team]
---

The ORC PMC is happy to add Deepak Majeti as an ORC committer for his
work on the C++ ORC reader including both contributions and reviews of
other's patches. Thank you for your work on ORC, Deepak!